// You are not expected to understand this JavaScript code for the lesson! In due time...

let formSubmissionDiv = document.querySelector('#submission')
formSubmissionDiv.style.display = 'none'

document.querySelector('form').addEventListener('submit', (event) => {
    event.preventDefault()
    document.querySelector('[type="submit"]').disabled = true
    formSubmissionDiv.style.display = 'block'

    document.querySelector('#name-output').textContent += 
        document.querySelector('#name').value

    document.querySelector('#bio-output').textContent += 
        document.querySelector('#bio').value

    document.querySelectorAll('[type="checkbox"]').forEach((checkbox) => {
        if (checkbox.checked) {
            document.querySelector('#hobbies-output').textContent += checkbox.value + ' '
        }
    })

    document.querySelectorAll('[type="radio"]').forEach((radio) => {
        if (radio.checked) {
            document.querySelector('#grade-output').textContent += radio.value
        }
    })

    document.querySelector('#fav-team-output').textContent += 
        document.querySelector('#favorite-team').value
})